const form = document.getElementById('downloadForm');
const input = document.getElementById('postUrl');
const button = document.getElementById('downloadBtn');
const statusBox = document.getElementById('status');
function showStatus(message, error=false) { statusBox.hidden=false; statusBox.textContent=message; statusBox.className='status'+(error?' error':''); }
document.getElementById('pasteBtn').addEventListener('click', async () => {
  try { input.value = await navigator.clipboard.readText(); input.focus(); }
  catch { showStatus('Clipboard tidak dapat diakses. Tempel tautan secara manual pada kolom.', true); }
});
form.addEventListener('submit', async e => {
  e.preventDefault();
  const url=input.value.trim();
  if(!url) return;
  button.disabled=true; button.innerHTML='<span>◌</span> MEMPROSES…';
  showStatus('Sedang memeriksa dan menyiapkan video. Proses dapat memerlukan waktu hingga beberapa menit.');
  try {
    const response=await fetch('/api/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url})});
    const type=response.headers.get('content-type')||'';
    if(!response.ok){const data=type.includes('application/json')?await response.json():{error:'Download gagal.'};throw new Error(data.error||'Download gagal.');}
    const blob=await response.blob();
    const disposition=response.headers.get('content-disposition')||'';
    const match=disposition.match(/filename="?([^";]+)"?/i);
    const filename=match?match[1]:'threads-video.mp4';
    const objectUrl=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=objectUrl; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(objectUrl);
    showStatus('Video berhasil diproses. Periksa folder Download pada perangkat Anda.');
  } catch(err) { showStatus(err.message+' Jika postingan publik tetap gagal, kemungkinan extractor belum mendukung format/link Threads tersebut.',true); }
  finally {button.disabled=false;button.innerHTML='<span>↓</span> DOWNLOAD VIDEO';}
});
